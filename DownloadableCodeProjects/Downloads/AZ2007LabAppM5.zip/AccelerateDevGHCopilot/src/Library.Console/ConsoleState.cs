﻿namespace Library.Console;

public enum ConsoleState
{
    PatronSearch,
    PatronSearchResults,
    PatronDetails,
    LoanDetails,
    Quit
}
